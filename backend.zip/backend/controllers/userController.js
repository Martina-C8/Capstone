// controllers/userController.js
import User from '../models/userModel.js';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';

// Genera il token JWT
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '30d' });
};

// Funzione per ottenere tutti gli utenti
export const getUsers = async (req, res) => {
  try {
    const users = await User.find({});
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Registrazione utente
export const registerUser = async (req, res) => {
  const { username, email, password } = req.body;

  const userExists = await User.findOne({ email });

  if (userExists) {
    res.status(400).json({ message: 'User already exists' });
    return;
  }

  const user = new User({ username, email, password });

  await user.save();
  
  res.status(201).json({
    _id: user._id,
    username: user.username,
    email: user.email,
    token: generateToken(user._id),
  });
};

// Login utente
export const loginUser = async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });

  if (user && (await bcrypt.compare(password, user.password))) {
    res.json({
      _id: user._id,
      username: user.username,
      email: user.email,
      token: generateToken(user._id),
    });
  } else {
    res.status(401).json({ message: 'Invalid credentials' });
  }
};

// Funzione per eliminare un utente
export const deleteUser = async (req, res) => {
  const { id } = req.params;

  try {
    const user = await User.findByIdAndDelete(id);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.status(200).json({ message: 'User deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Funzione per aggiornare i progressi del gioco
export const updateProgress = async (req, res) => {
  const { game, progress } = req.body; // `game` è il nome del gioco, `progress` è l'oggetto con i progressi
  const { id } = req.user; // ID dell'utente autenticato

  try {
    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    user.progress[game] = progress; // Aggiorna i progressi per il gioco specificato
    await user.save();

    res.status(200).json({ message: 'Progress updated successfully', progress: user.progress });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};



// Funzione per la rotta protetta
export const protectedRoute = (req, res) => {
  res.json({ message: 'This is a protected route' });
};
