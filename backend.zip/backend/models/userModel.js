// models/userModel.js
import mongoose from 'mongoose';
import bcrypt from 'bcrypt';

// const userSchema = new mongoose.Schema({
//   username: { type: String, required: true, unique: true },
//   email: { type: String, required: true, unique: true },
//   password: { type: String, required: true },
//   progress: {
//     fifteen: { type: Object, default: {} },
//     sudoku: { type: Object, default: {} },
//     quiz: { type: Object, default: {} },
//     memory: { type: Object, default: {} },
//     ticTacToe: {
//       board: { type: [String], default: [] }, // Stato del tabellone di Tic Tac Toe
//       moves: { type: Number, default: 0 }     // Numero di mosse
//     }
//   },
// });
const userSchema = mongoose.Schema(
  {
    username: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    scores: {
      type: Map,
      of: Number,
      default: {},

    },
  },
  {
    timestamps: true,
  }
);

//non embeddato, modello a parte con roba da riga 10 a 17 che in più ha un id utente
// Hash della password prima di salvare l'utente
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) {
    next();
  }
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

const User = mongoose.model('User', userSchema);

export default User;
