import express from 'express';
import { saveScore } from '../controllers/scoreController.js';
import { authenticateToken } from '../middleware/authMiddleware.js';
const router = express.Router();

// Rotta per salvare i punteggi dell'utente
router.post('/saveScore', authenticateToken, saveScore); // `protect` per verificare l'autenticazione

export default router;
