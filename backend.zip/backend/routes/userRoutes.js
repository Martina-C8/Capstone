// routes/userRoutes.js
import express from 'express';
import { authenticateToken } from '../middleware/authMiddleware.js'; 
import { registerUser, loginUser, getUsers, deleteUser, updateProgress, protectedRoute } from '../controllers/userController.js';

const router = express.Router();

router.post('/register', registerUser);
router.post('/login', loginUser);
router.get('/', getUsers); // avere lista utenti
router.delete('/:id', deleteUser); // eliminare un utente
router.patch('/progress', authenticateToken, updateProgress); // Aggiungi questa riga
router.get('/protected-route', authenticateToken, protectedRoute);

export default router;
